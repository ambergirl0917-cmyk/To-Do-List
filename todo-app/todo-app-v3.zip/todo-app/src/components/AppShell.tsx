'use client'
import { useState, useEffect } from 'react'
import type { User } from '@supabase/supabase-js'
import { supabase } from '@/lib/supabase'
import Sidebar from './Sidebar'
import TopBar from './TopBar'
import OverviewPage from './pages/OverviewPage'
import SubjectsPage from './pages/SubjectsPage'
import IBCorePage from './pages/IBCorePage'
import SATPage from './pages/SATPage'
import ExtracurricularPage from './pages/ExtracurricularPage'
import CollegeAppPage from './pages/CollegeAppPage'
import WeeklyPlannerPage from './pages/WeeklyPlannerPage'
import DeadlinesPage from './pages/DeadlinesPage'
import ArchivePage from './pages/ArchivePage'
import SettingsPage from './pages/SettingsPage'
import { Task } from '@/lib/types'

export type PageId = 'overview' | 'subjects' | 'ibcore' | 'sat' | 'extracurricular' | 'college' | 'planner' | 'deadlines' | 'archive' | 'settings'

interface AppShellProps { user: User }

export default function AppShell({ user }: AppShellProps) {
  const [currentPage, setCurrentPage] = useState<PageId>('overview')
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [urgentTasks, setUrgentTasks] = useState<Task[]>([])
  const [upcomingTasks, setUpcomingTasks] = useState<Task[]>([])
  const [focusMode, setFocusMode] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')

  useEffect(() => {
    fetchUrgentTasks()
  }, [user])

  const fetchUrgentTasks = async () => {
    const today = new Date()
    const todayStr = today.toISOString().split('T')[0]
    
    // Fetch all upcoming tasks sorted by date
    const { data } = await supabase
      .from('tasks')
      .select('*')
      .eq('user_id', user.id)
      .eq('is_archived', false)
      .neq('progress', '100%')
      .not('due_date', 'is', null)
      .gte('due_date', todayStr)
      .order('due_date', { ascending: true })
      .limit(20)

    if (data) {
      // Urgent = due within 2 days (or custom reminder_days)
      const urgent = data.filter(t => {
        const dueDate = new Date(t.due_date)
        const diff = Math.floor((dueDate.getTime() - today.setHours(0,0,0,0)) / (1000 * 60 * 60 * 24))
        const threshold = t.reminder_days ?? 2
        return diff >= 0 && diff <= threshold
      })
      // Upcoming = next 5 after urgent ones
      const urgentIds = new Set(urgent.map((t: Task) => t.id))
      const upcoming = data.filter((t: Task) => !urgentIds.has(t.id)).slice(0, 5)
      
      setUrgentTasks(urgent)
      setUpcomingTasks(upcoming)
    }
  }

  const renderPage = () => {
    const props = { user, onTaskChange: fetchUrgentTasks, focusMode, searchQuery }
    switch (currentPage) {
      case 'overview': return <OverviewPage {...props} />
      case 'subjects': return <SubjectsPage {...props} />
      case 'ibcore': return <IBCorePage {...props} />
      case 'sat': return <SATPage {...props} />
      case 'extracurricular': return <ExtracurricularPage {...props} />
      case 'college': return <CollegeAppPage {...props} />
      case 'planner': return <WeeklyPlannerPage user={user} />
      case 'deadlines': return <DeadlinesPage user={user} />
      case 'archive': return <ArchivePage user={user} />
      case 'settings': return <SettingsPage user={user} />
      default: return <OverviewPage {...props} />
    }
  }

  return (
    <div className="flex flex-col h-screen overflow-hidden">
      <TopBar
        user={user}
        urgentTasks={urgentTasks}
        upcomingTasks={upcomingTasks}
        focusMode={focusMode}
        onToggleFocus={() => setFocusMode(f => !f)}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onToggleSidebar={() => setSidebarOpen(s => !s)}
      />
      <div className="flex flex-1 overflow-hidden">
        {sidebarOpen && (
          <Sidebar currentPage={currentPage} onNavigate={setCurrentPage} />
        )}
        <main className="flex-1 overflow-y-auto p-4 md:p-6">
          {renderPage()}
        </main>
      </div>
    </div>
  )
}
