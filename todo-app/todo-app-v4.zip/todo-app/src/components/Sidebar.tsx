'use client'
import { PageId } from './AppShell'

interface SidebarProps {
  currentPage: PageId
  onNavigate: (page: PageId) => void
}

export default function Sidebar({ currentPage, onNavigate }: SidebarProps) {
  const item = (id: PageId, label: string, icon?: string) => (
    <button
      key={id}
      onClick={() => onNavigate(id)}
      className={`w-full text-left flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-all ${
        currentPage === id
          ? 'bg-pink-100 text-pink-700 font-medium border-l-2 border-pink-500'
          : 'text-gray-500 hover:bg-pink-50 hover:text-pink-600'
      }`}
    >
      {icon && <span className="text-base">{icon}</span>}
      <span className="truncate">{label}</span>
    </button>
  )

  return (
    <div className="w-40 md:w-44 bg-white border-r border-pink-100 flex flex-col py-3 overflow-y-auto flex-shrink-0">
      <div className="px-2 mb-1">
        <p className="text-xs font-semibold text-pink-300 uppercase tracking-wider mb-1 px-1">Overview</p>
        {item('overview', "Today's & ASAP", '📋')}
      </div>
      <div className="px-2 mb-1 mt-2">
        <p className="text-xs font-semibold text-pink-300 uppercase tracking-wider mb-1 px-1">IB Subjects</p>
        {item('subjects', 'All Subjects', '📚')}
      </div>
      <div className="px-2 mb-1 mt-2">
        <p className="text-xs font-semibold text-pink-300 uppercase tracking-wider mb-1 px-1">IB Core</p>
        {item('ibcore', 'TOK / EE / CAS', '🌐')}
      </div>
      <div className="px-2 mb-1 mt-2">
        <p className="text-xs font-semibold text-pink-300 uppercase tracking-wider mb-1 px-1">Other</p>
        {item('sat', 'SAT', '📝')}
        {item('extracurricular', 'Extracurricular', '✨')}
        {item('college', 'College App', '🎓')}
        {item('planner', 'Weekly Planner', '📅')}
        {item('deadlines', 'Deadlines', '🔔')}
      </div>
      <div className="px-2 mb-1 mt-2">
        <p className="text-xs font-semibold text-pink-300 uppercase tracking-wider mb-1 px-1">More</p>
        {item('archive', 'Archive', '📦')}
        {item('settings', 'Settings', '⚙️')}
      </div>
    </div>
  )
}
